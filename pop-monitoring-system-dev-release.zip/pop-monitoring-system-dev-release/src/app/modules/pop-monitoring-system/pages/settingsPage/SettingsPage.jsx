import './SettingsPage.scss'
const SettingsPage = () => {
  return (
    <main className='h-full'>
      <h1>SettingsPage</h1>
    </main>
  )
}

export default SettingsPage
